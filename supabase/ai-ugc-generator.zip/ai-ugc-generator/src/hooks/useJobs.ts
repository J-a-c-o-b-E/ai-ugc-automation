// src/hooks/useJobs.ts

import { useState, useEffect, useCallback } from 'react';
import { supabase, callEdgeFunction } from '../lib/supabase';
import type { Job, Segment, Log, Character } from '../types';

export function useJobs() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchJobs = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*, characters(*)')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setJobs(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch jobs');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchJobs();

    // Subscribe to realtime changes
    const channel = supabase
      .channel('jobs-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'jobs' },
        () => fetchJobs()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchJobs]);

  const createJob = async (tiktokUrl: string, characterId: string) => {
    const { data, error } = await supabase
      .from('jobs')
      .insert({
        tiktok_url: tiktokUrl,
        character_id: characterId,
        status: 'pending',
        current_step: 0,
        total_steps: 7,
      })
      .select()
      .single();

    if (error) throw error;
    return data;
  };

  const startProcessing = async (jobId: string) => {
    return callEdgeFunction('process-pipeline', { jobId });
  };

  return { jobs, loading, error, createJob, startProcessing, refetch: fetchJobs };
}

export function useJob(jobId: string) {
  const [job, setJob] = useState<Job | null>(null);
  const [segments, setSegments] = useState<Segment[]>([]);
  const [logs, setLogs] = useState<Log[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchJob = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*, characters(*)')
        .eq('id', jobId)
        .single();

      if (error) throw error;
      setJob(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch job');
    }
  }, [jobId]);

  const fetchSegments = useCallback(async () => {
    const { data, error } = await supabase
      .from('segments')
      .select('*')
      .eq('job_id', jobId)
      .order('segment_index');

    if (!error && data) {
      setSegments(data);
    }
  }, [jobId]);

  const fetchLogs = useCallback(async () => {
    const { data, error } = await supabase
      .from('logs')
      .select('*')
      .eq('job_id', jobId)
      .order('created_at');

    if (!error && data) {
      setLogs(data);
    }
  }, [jobId]);

  useEffect(() => {
    const loadAll = async () => {
      setLoading(true);
      await Promise.all([fetchJob(), fetchSegments(), fetchLogs()]);
      setLoading(false);
    };

    loadAll();

    // Subscribe to realtime changes
    const channel = supabase
      .channel(`job-${jobId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'jobs', filter: `id=eq.${jobId}` },
        (payload) => setJob(payload.new as Job)
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'segments', filter: `job_id=eq.${jobId}` },
        () => fetchSegments()
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'logs', filter: `job_id=eq.${jobId}` },
        (payload) => setLogs((prev) => [...prev, payload.new as Log])
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [jobId, fetchJob, fetchSegments, fetchLogs]);

  return { job, segments, logs, loading, error };
}

export function useCharacters() {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchCharacters = useCallback(async () => {
    try {
      const { data, error } = await supabase
        .from('characters')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCharacters(data || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to fetch characters');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCharacters();
  }, [fetchCharacters]);

  const createCharacter = async (name: string, description: string) => {
    const { data, error } = await supabase
      .from('characters')
      .insert({ name, description })
      .select()
      .single();

    if (error) throw error;
    await fetchCharacters();
    return data;
  };

  const updateCharacter = async (id: string, name: string, description: string) => {
    const { error } = await supabase
      .from('characters')
      .update({ name, description })
      .eq('id', id);

    if (error) throw error;
    await fetchCharacters();
  };

  const deleteCharacter = async (id: string) => {
    const { error } = await supabase.from('characters').delete().eq('id', id);

    if (error) throw error;
    await fetchCharacters();
  };

  return {
    characters,
    loading,
    error,
    createCharacter,
    updateCharacter,
    deleteCharacter,
    refetch: fetchCharacters,
  };
}

// src/types/index.ts

export interface Character {
  id: string;
  user_id?: string;
  name: string;
  description: string;
  is_default?: boolean;
  created_at: string;
  updated_at?: string;
}

export interface Job {
  id: string;
  user_id?: string;
  character_id: string;
  tiktok_url: string;
  original_video_url?: string;
  video_duration?: number;
  status: JobStatus;
  current_step: number;
  total_steps: number;
  error_message?: string;
  created_at: string;
  updated_at: string;
  characters?: Character;
}

export type JobStatus =
  | 'pending'
  | 'downloading'
  | 'analyzing'
  | 'extracting'
  | 'generating_images'
  | 'generating_videos'
  | 'complete'
  | 'error';

export interface Segment {
  id: string;
  job_id: string;
  segment_index: number;
  start_time: number;
  end_time: number;
  duration: number;
  final_duration?: number;
  is_looped: boolean;
  loop_count: number;
  segment_video_url?: string;
  first_frame_url?: string;
  ai_character_image_url?: string;
  clean_image_url?: string;
  output_video_url?: string;
  status: SegmentStatus;
  error_message?: string;
  created_at: string;
  updated_at: string;
}

export type SegmentStatus =
  | 'pending'
  | 'cut'
  | 'frame_extracted'
  | 'image_generated'
  | 'image_cleaned'
  | 'video_generating'
  | 'complete'
  | 'error';

export interface Log {
  id: string;
  job_id: string;
  message: string;
  log_type: 'info' | 'success' | 'warning' | 'error';
  created_at: string;
}

export interface ApiKeys {
  id: string;
  user_id: string;
  wavespeed_key_encrypted?: string;
  gemini_key_encrypted?: string;
  created_at: string;
  updated_at: string;
}

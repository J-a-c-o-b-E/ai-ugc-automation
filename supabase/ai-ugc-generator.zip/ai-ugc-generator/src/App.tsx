// src/App.tsx

import React, { useState, useEffect, useRef } from 'react';
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
  useNavigate,
  useParams,
} from 'react-router-dom';
import {
  Video,
  User,
  Settings,
  Plus,
  Play,
  Download,
  Trash2,
  Edit,
  ExternalLink,
  Zap,
  Clock,
  CheckCircle,
  AlertCircle,
  Loader2,
  ChevronRight,
  RefreshCw,
} from 'lucide-react';
import {
  Button,
  Card,
  Input,
  Textarea,
  Select,
  StatusBadge,
  ProgressRing,
  Modal,
} from './components/ui';
import { useJobs, useJob, useCharacters } from './hooks/useJobs';
import type { Job, Character, Segment, Log } from './types';

// Header Component
function Header() {
  return (
    <header className="border-b border-zinc-800/50 bg-zinc-900/50 backdrop-blur-xl sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center shadow-lg shadow-violet-500/25">
            <Video className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight">AI UGC Generator</h1>
            <p className="text-xs text-zinc-500">Powered by WaveSpeed + Kling AI</p>
          </div>
        </Link>

        <nav className="flex items-center gap-2">
          <Link to="/">
            <Button variant="ghost" size="sm">
              <Zap className="w-4 h-4 mr-2" />
              Jobs
            </Button>
          </Link>
          <Link to="/characters">
            <Button variant="ghost" size="sm">
              <User className="w-4 h-4 mr-2" />
              Characters
            </Button>
          </Link>
          <Link to="/settings">
            <Button variant="ghost" size="sm">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </Link>
        </nav>
      </div>
    </header>
  );
}

// Dashboard Page - List of Jobs
function DashboardPage() {
  const { jobs, loading, createJob, startProcessing } = useJobs();
  const { characters } = useCharacters();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [tiktokUrl, setTiktokUrl] = useState('');
  const [selectedCharacter, setSelectedCharacter] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (characters.length > 0 && !selectedCharacter) {
      const defaultChar = characters.find((c) => c.is_default) || characters[0];
      setSelectedCharacter(defaultChar.id);
    }
  }, [characters, selectedCharacter]);

  const handleCreateJob = async () => {
    if (!tiktokUrl || !selectedCharacter) return;

    setIsCreating(true);
    try {
      const job = await createJob(tiktokUrl, selectedCharacter);
      setIsModalOpen(false);
      setTiktokUrl('');
      navigate(`/job/${job.id}`);
      // Start processing in background
      startProcessing(job.id);
    } catch (err) {
      console.error('Failed to create job:', err);
    } finally {
      setIsCreating(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'complete':
        return <CheckCircle className="w-5 h-5 text-emerald-400" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-400" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-zinc-400" />;
      default:
        return <Loader2 className="w-5 h-5 text-violet-400 animate-spin" />;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-violet-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold">Your Jobs</h2>
          <p className="text-zinc-400 mt-1">
            Generate AI UGC videos from TikTok content
          </p>
        </div>
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Job
        </Button>
      </div>

      {jobs.length === 0 ? (
        <Card className="text-center py-12">
          <Video className="w-12 h-12 text-zinc-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-zinc-300 mb-2">No jobs yet</h3>
          <p className="text-zinc-500 mb-4">
            Create your first AI UGC video transformation
          </p>
          <Button onClick={() => setIsModalOpen(true)}>
            <Plus className="w-4 h-4 mr-2" />
            Create Job
          </Button>
        </Card>
      ) : (
        <div className="space-y-4">
          {jobs.map((job) => (
            <Link key={job.id} to={`/job/${job.id}`}>
              <Card className="hover:border-zinc-700 transition-colors cursor-pointer">
                <div className="flex items-center gap-4">
                  {getStatusIcon(job.status)}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-zinc-200 truncate">
                        {job.tiktok_url}
                      </p>
                      <StatusBadge status={job.status} />
                    </div>
                    <p className="text-xs text-zinc-500 mt-1">
                      {job.characters?.name || 'Unknown character'} •{' '}
                      {new Date(job.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-3">
                    <ProgressRing
                      progress={(job.current_step / job.total_steps) * 100}
                      size={40}
                    />
                    <ChevronRight className="w-5 h-5 text-zinc-600" />
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}

      {/* New Job Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Create New Job"
      >
        <div className="space-y-4">
          <Input
            label="TikTok URL"
            placeholder="https://www.tiktok.com/@user/video/..."
            value={tiktokUrl}
            onChange={(e) => setTiktokUrl(e.target.value)}
          />
          <Select
            label="AI Character"
            value={selectedCharacter}
            onChange={(e) => setSelectedCharacter(e.target.value)}
            options={characters.map((c) => ({ value: c.id, label: c.name }))}
          />
          <div className="flex justify-end gap-3 mt-6">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateJob}
              isLoading={isCreating}
              disabled={!tiktokUrl || !selectedCharacter}
            >
              <Play className="w-4 h-4 mr-2" />
              Start Processing
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// Job Detail Page
function JobDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { job, segments, logs, loading } = useJob(id!);
  const logsEndRef = useRef<HTMLDivElement>(null);
  const { startProcessing } = useJobs();

  // Auto-scroll logs
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const getLogColor = (type: string) => {
    switch (type) {
      case 'success':
        return 'text-emerald-400';
      case 'warning':
        return 'text-amber-400';
      case 'error':
        return 'text-red-400';
      default:
        return 'text-zinc-400';
    }
  };

  const pipelineSteps = [
    { step: 1, name: 'Download', status: job?.current_step >= 1 },
    { step: 2, name: 'Analyze', status: job?.current_step >= 2 },
    { step: 3, name: 'Extract', status: job?.current_step >= 3 },
    { step: 4, name: 'Generate Images', status: job?.current_step >= 4 },
    { step: 5, name: 'Clean Images', status: job?.current_step >= 5 },
    { step: 6, name: 'Generate Videos', status: job?.current_step >= 6 },
    { step: 7, name: 'Complete', status: job?.current_step >= 7 },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-violet-500 animate-spin" />
      </div>
    );
  }

  if (!job) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        <Card className="text-center py-12">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-zinc-300">Job not found</h3>
        </Card>
      </div>
    );
  }

  const progress = (job.current_step / job.total_steps) * 100;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h2 className="text-2xl font-bold">Job Details</h2>
            <StatusBadge status={job.status} />
          </div>
          <p className="text-zinc-400 text-sm truncate max-w-lg">
            {job.tiktok_url}
          </p>
          <p className="text-zinc-500 text-xs mt-1">
            Character: {job.characters?.name} • Created:{' '}
            {new Date(job.created_at).toLocaleString()}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <ProgressRing progress={progress} size={56} />
          {job.status === 'error' && (
            <Button
              variant="secondary"
              size="sm"
              onClick={() => startProcessing(job.id)}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          )}
        </div>
      </div>

      {/* Pipeline Progress */}
      <Card className="mb-6">
        <h3 className="text-sm font-semibold text-zinc-300 mb-4">
          Processing Pipeline
        </h3>
        <div className="flex items-center justify-between">
          {pipelineSteps.map((step, idx) => (
            <React.Fragment key={step.step}>
              <div className="flex flex-col items-center">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                    step.status
                      ? 'bg-violet-500 text-white'
                      : 'bg-zinc-800 text-zinc-500'
                  }`}
                >
                  {step.status && job.current_step > step.step ? (
                    <CheckCircle className="w-4 h-4" />
                  ) : (
                    step.step
                  )}
                </div>
                <span
                  className={`text-xs mt-2 ${
                    step.status ? 'text-zinc-300' : 'text-zinc-600'
                  }`}
                >
                  {step.name}
                </span>
              </div>
              {idx < pipelineSteps.length - 1 && (
                <div
                  className={`flex-1 h-0.5 mx-2 ${
                    step.status ? 'bg-violet-500' : 'bg-zinc-800'
                  }`}
                />
              )}
            </React.Fragment>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Segments */}
        <Card>
          <h3 className="text-sm font-semibold text-zinc-300 mb-4">
            UGC Segments ({segments.length})
          </h3>
          {segments.length === 0 ? (
            <p className="text-zinc-500 text-sm">
              No segments detected yet...
            </p>
          ) : (
            <div className="space-y-3">
              {segments.map((segment) => (
                <div
                  key={segment.id}
                  className="p-3 bg-zinc-800/50 rounded-xl border border-zinc-700/50"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-zinc-200">
                      Segment {segment.segment_index + 1}
                    </span>
                    <StatusBadge status={segment.status} />
                  </div>
                  <div className="text-xs text-zinc-500 space-y-1">
                    <p>
                      Time: {segment.start_time.toFixed(1)}s -{' '}
                      {segment.end_time.toFixed(1)}s ({segment.duration.toFixed(1)}s)
                    </p>
                    {segment.is_looped && (
                      <p className="text-amber-400">
                        ⟳ Looped {segment.loop_count}x to reach minimum duration
                      </p>
                    )}
                  </div>
                  {segment.output_video_url && (
                    <div className="mt-3 flex gap-2">
                      <a
                        href={segment.output_video_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex-1"
                      >
                        <Button variant="secondary" size="sm" className="w-full">
                          <Play className="w-3 h-3 mr-1" />
                          Preview
                        </Button>
                      </a>
                      <a
                        href={segment.output_video_url}
                        download={`ai_ugc_segment_${segment.segment_index + 1}.mp4`}
                      >
                        <Button variant="primary" size="sm">
                          <Download className="w-3 h-3 mr-1" />
                          Download
                        </Button>
                      </a>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Processing Logs */}
        <Card>
          <h3 className="text-sm font-semibold text-zinc-300 mb-4">
            Processing Log
          </h3>
          <div className="bg-zinc-950 rounded-xl p-4 h-96 overflow-y-auto font-mono text-xs">
            {logs.length === 0 ? (
              <p className="text-zinc-600">Waiting for processing to start...</p>
            ) : (
              logs.map((log) => (
                <div key={log.id} className="mb-1">
                  <span className="text-zinc-600">
                    [{new Date(log.created_at).toLocaleTimeString()}]
                  </span>{' '}
                  <span className={getLogColor(log.log_type)}>{log.message}</span>
                </div>
              ))
            )}
            <div ref={logsEndRef} />
          </div>
        </Card>
      </div>

      {/* Error Message */}
      {job.error_message && (
        <Card className="mt-6 border-red-500/30 bg-red-500/5">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-medium text-red-400">Error</h4>
              <p className="text-sm text-red-300/80 mt-1">{job.error_message}</p>
            </div>
          </div>
        </Card>
      )}

      {/* Download All Button */}
      {job.status === 'complete' && segments.some((s) => s.output_video_url) && (
        <Card className="mt-6 border-emerald-500/30 bg-emerald-500/5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-emerald-400" />
              <div>
                <h4 className="text-sm font-medium text-emerald-400">
                  All videos generated!
                </h4>
                <p className="text-xs text-emerald-300/60">
                  {segments.filter((s) => s.output_video_url).length} videos ready
                  for download
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              {segments
                .filter((s) => s.output_video_url)
                .map((s) => (
                  <a
                    key={s.id}
                    href={s.output_video_url!}
                    download={`ai_ugc_${s.segment_index + 1}.mp4`}
                  >
                    <Button size="sm">
                      <Download className="w-4 h-4 mr-1" />
                      Segment {s.segment_index + 1}
                    </Button>
                  </a>
                ))}
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}

// Characters Page
function CharactersPage() {
  const {
    characters,
    loading,
    createCharacter,
    updateCharacter,
    deleteCharacter,
  } = useCharacters();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCharacter, setEditingCharacter] = useState<Character | null>(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  const handleOpenCreate = () => {
    setEditingCharacter(null);
    setName('');
    setDescription('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (character: Character) => {
    setEditingCharacter(character);
    setName(character.name);
    setDescription(character.description);
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (!name || !description) return;

    setIsSaving(true);
    try {
      if (editingCharacter) {
        await updateCharacter(editingCharacter.id, name, description);
      } else {
        await createCharacter(name, description);
      }
      setIsModalOpen(false);
      setName('');
      setDescription('');
      setEditingCharacter(null);
    } catch (err) {
      console.error('Failed to save character:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this character?')) return;
    try {
      await deleteCharacter(id);
    } catch (err) {
      console.error('Failed to delete character:', err);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 text-violet-500 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold">AI Characters</h2>
          <p className="text-zinc-400 mt-1">
            Define reusable AI character descriptions
          </p>
        </div>
        <Button onClick={handleOpenCreate}>
          <Plus className="w-4 h-4 mr-2" />
          New Character
        </Button>
      </div>

      <div className="space-y-4">
        {characters.map((character) => (
          <Card key={character.id}>
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="text-lg font-semibold text-zinc-200">
                    {character.name}
                  </h3>
                  {character.is_default && (
                    <span className="px-2 py-0.5 text-xs bg-violet-500/20 text-violet-400 rounded-full">
                      Default
                    </span>
                  )}
                </div>
                <p className="text-sm text-zinc-400 whitespace-pre-wrap">
                  {character.description}
                </p>
              </div>
              <div className="flex gap-2 ml-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleOpenEdit(character)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
                {!character.is_default && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(character.id)}
                  >
                    <Trash2 className="w-4 h-4 text-red-400" />
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Character Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={editingCharacter ? 'Edit Character' : 'New Character'}
      >
        <div className="space-y-4">
          <Input
            label="Character Name"
            placeholder="e.g., Jade Miller"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <Textarea
            label="Character Description"
            placeholder="Detailed appearance description..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={10}
          />
          <div className="flex justify-end gap-3 mt-6">
            <Button variant="secondary" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              isLoading={isSaving}
              disabled={!name || !description}
            >
              {editingCharacter ? 'Update' : 'Create'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// Settings Page
function SettingsPage() {
  const [wavespeedKey, setWavespeedKey] = useState('');
  const [geminiKey, setGeminiKey] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    // In a real app, you'd save these to Supabase Edge Function secrets
    // For now, we'll just show a success message
    await new Promise((r) => setTimeout(r, 1000));
    setIsSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 py-8">
      <div className="mb-8">
        <h2 className="text-2xl font-bold">Settings</h2>
        <p className="text-zinc-400 mt-1">Configure your API keys</p>
      </div>

      <Card>
        <div className="space-y-6">
          <div className="p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
            <h4 className="text-sm font-medium text-amber-400 mb-2">
              ⚠️ API Keys Required
            </h4>
            <p className="text-xs text-amber-300/70">
              To use this app, you need to add your API keys to Supabase Edge
              Function Secrets. Go to your Supabase dashboard → Edge Functions →
              Secrets and add:
            </p>
            <ul className="text-xs text-amber-300/70 mt-2 list-disc list-inside">
              <li>WAVESPEED_API_KEY - from wavespeed.ai</li>
              <li>GEMINI_API_KEY - from Google AI Studio</li>
            </ul>
          </div>

          <Input
            label="WaveSpeed API Key"
            type="password"
            placeholder="ws_..."
            value={wavespeedKey}
            onChange={(e) => setWavespeedKey(e.target.value)}
          />
          <p className="text-xs text-zinc-500 -mt-4">
            Get your key at{' '}
            <a
              href="https://wavespeed.ai"
              target="_blank"
              rel="noopener noreferrer"
              className="text-violet-400 hover:underline"
            >
              wavespeed.ai
            </a>
          </p>

          <Input
            label="Gemini API Key"
            type="password"
            placeholder="AIza..."
            value={geminiKey}
            onChange={(e) => setGeminiKey(e.target.value)}
          />
          <p className="text-xs text-zinc-500 -mt-4">
            Get your key at{' '}
            <a
              href="https://aistudio.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="text-violet-400 hover:underline"
            >
              Google AI Studio
            </a>
          </p>

          <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
            {saved && (
              <span className="text-sm text-emerald-400">
                ✓ Settings saved (add to Supabase Secrets)
              </span>
            )}
            <div className="flex-1" />
            <Button onClick={handleSave} isLoading={isSaving}>
              Save Settings
            </Button>
          </div>
        </div>
      </Card>

      <Card className="mt-6">
        <h3 className="text-sm font-semibold text-zinc-300 mb-4">
          API Pricing Reference
        </h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between text-zinc-400">
            <span>TikTok Download</span>
            <span className="text-emerald-400">Free (tikwm.com)</span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>Video Analysis (Molmo2)</span>
            <span>~$0.005/video</span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>Gemini Image Generation</span>
            <span className="text-emerald-400">Free tier</span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>Watermark Removal</span>
            <span>$0.015/image</span>
          </div>
          <div className="flex justify-between text-zinc-400">
            <span>Kling Motion Control</span>
            <span>$0.336/video</span>
          </div>
          <div className="flex justify-between text-zinc-200 font-medium pt-2 border-t border-zinc-800">
            <span>Total per segment</span>
            <span>~$0.36</span>
          </div>
        </div>
      </Card>
    </div>
  );
}

// Main App
export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-zinc-950 text-white">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/job/:id" element={<JobDetailPage />} />
            <Route path="/characters" element={<CharactersPage />} />
            <Route path="/settings" element={<SettingsPage />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

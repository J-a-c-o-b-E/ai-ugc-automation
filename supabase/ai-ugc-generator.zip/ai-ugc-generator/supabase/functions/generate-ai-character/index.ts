// supabase/functions/generate-ai-character/index.ts
// Generates AI character image using Gemini and removes watermark using WaveSpeed

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { encode as base64Encode } from "https://deno.land/std@0.168.0/encoding/base64.ts";
import { decode as base64Decode } from "https://deno.land/std@0.168.0/encoding/base64.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const WAVESPEED_API_BASE = "https://api.wavespeed.ai/api/v3";

async function pollForResult(
  requestId: string,
  apiKey: string,
  maxAttempts = 30,
  intervalMs = 2000
): Promise<any> {
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise((r) => setTimeout(r, intervalMs));

    const response = await fetch(
      `${WAVESPEED_API_BASE}/predictions/${requestId}/result`,
      {
        headers: { Authorization: `Bearer ${apiKey}` },
      }
    );

    const data = await response.json();

    if (data.status === "completed") {
      return data;
    } else if (data.status === "failed") {
      throw new Error(data.error || "Processing failed");
    }
  }

  throw new Error("Processing timed out");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { segmentId, frameUrl, characterDescription, characterName, jobId } = await req.json();

    if (!segmentId || !frameUrl || !characterDescription || !jobId) {
      throw new Error("Missing required parameters");
    }

    const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");
    const WAVESPEED_API_KEY = Deno.env.get("WAVESPEED_API_KEY");

    if (!GEMINI_API_KEY) {
      throw new Error("GEMINI_API_KEY not configured");
    }
    if (!WAVESPEED_API_KEY) {
      throw new Error("WAVESPEED_API_KEY not configured");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `🎨 Generating AI character "${characterName}" for segment...`,
      log_type: "info",
    });

    // Update segment status
    await supabase
      .from("segments")
      .update({ status: "image_generated" })
      .eq("id", segmentId);

    // Fetch the frame image as base64
    const frameResponse = await fetch(frameUrl);
    if (!frameResponse.ok) {
      throw new Error(`Failed to fetch frame: ${frameResponse.status}`);
    }

    const frameArrayBuffer = await frameResponse.arrayBuffer();
    const frameBase64 = base64Encode(new Uint8Array(frameArrayBuffer));

    // Determine mime type
    const contentType = frameResponse.headers.get("content-type") || "image/png";
    const mimeType = contentType.includes("jpeg") || contentType.includes("jpg") 
      ? "image/jpeg" 
      : "image/png";

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "  → Calling Gemini API to generate character...",
      log_type: "info",
    });

    // Call Gemini API to generate the AI character image
    const geminiResponse = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  inline_data: {
                    mime_type: mimeType,
                    data: frameBase64,
                  },
                },
                {
                  text: `You are an expert image editor. Your task is to replace the person in this image with a new character while keeping EVERYTHING else exactly the same.

KEEP UNCHANGED:
- Background
- Lighting
- Camera angle
- Framing/composition
- Any objects in the scene
- The pose and position of the person

REPLACE the person with someone who looks like this:
${characterDescription}

The new character should be in the EXACT same pose, position, and have the same body language as the original person. Make sure the replacement looks natural and seamlessly integrated into the scene.

Generate a photorealistic image with the character replacement.`,
                },
              ],
            },
          ],
          generationConfig: {
            responseModalities: ["image", "text"],
            responseMimeType: "image/png",
          },
        }),
      }
    );

    if (!geminiResponse.ok) {
      const errorText = await geminiResponse.text();
      throw new Error(`Gemini API error: ${geminiResponse.status} - ${errorText}`);
    }

    const geminiResult = await geminiResponse.json();

    // Extract the generated image
    let generatedImageBase64: string | null = null;
    const candidates = geminiResult.candidates || [];

    for (const candidate of candidates) {
      const parts = candidate.content?.parts || [];
      for (const part of parts) {
        if (part.inline_data?.data) {
          generatedImageBase64 = part.inline_data.data;
          break;
        }
      }
      if (generatedImageBase64) break;
    }

    if (!generatedImageBase64) {
      throw new Error("Gemini did not generate an image. Response: " + JSON.stringify(geminiResult).substring(0, 500));
    }

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "  ✓ AI character image generated",
      log_type: "success",
    });

    // Upload AI-generated image to Supabase Storage
    const aiImageBytes = base64Decode(generatedImageBase64);
    const aiFileName = `${jobId}/ai_character_${segmentId}.png`;

    const { error: aiUploadError } = await supabase.storage
      .from("images")
      .upload(aiFileName, aiImageBytes, {
        contentType: "image/png",
        upsert: true,
      });

    if (aiUploadError) {
      throw new Error(`Failed to upload AI image: ${aiUploadError.message}`);
    }

    const { data: aiUrlData } = supabase.storage
      .from("images")
      .getPublicUrl(aiFileName);

    const aiImageUrl = aiUrlData.publicUrl;

    // Update segment with AI image URL
    await supabase
      .from("segments")
      .update({ ai_character_image_url: aiImageUrl })
      .eq("id", segmentId);

    // Now remove watermark using WaveSpeed API
    await supabase.from("logs").insert({
      job_id: jobId,
      message: "  🧹 Removing Gemini watermark...",
      log_type: "info",
    });

    const watermarkResponse = await fetch(
      `${WAVESPEED_API_BASE}/wavespeed-ai/image-watermark-remover`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${WAVESPEED_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          image: aiImageUrl,
          output_format: "png",
        }),
      }
    );

    if (!watermarkResponse.ok) {
      console.error("Watermark removal API error:", await watermarkResponse.text());
      // Continue with original image if watermark removal fails
      await supabase
        .from("segments")
        .update({ clean_image_url: aiImageUrl, status: "image_cleaned" })
        .eq("id", segmentId);

      await supabase.from("logs").insert({
        job_id: jobId,
        message: "  ⚠️ Watermark removal skipped, using original",
        log_type: "warning",
      });

      return new Response(
        JSON.stringify({
          success: true,
          aiImageUrl,
          cleanImageUrl: aiImageUrl,
        }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const watermarkResult = await watermarkResponse.json();

    // Poll for watermark removal result
    let cleanImageUrl = aiImageUrl;
    if (watermarkResult.id) {
      try {
        const result = await pollForResult(watermarkResult.id, WAVESPEED_API_KEY, 20, 1500);
        cleanImageUrl = result.outputs?.[0] || aiImageUrl;

        // Download and re-upload to our storage for persistence
        if (cleanImageUrl !== aiImageUrl) {
          const cleanResponse = await fetch(cleanImageUrl);
          if (cleanResponse.ok) {
            const cleanBlob = await cleanResponse.arrayBuffer();
            const cleanFileName = `${jobId}/clean_character_${segmentId}.png`;

            await supabase.storage
              .from("images")
              .upload(cleanFileName, cleanBlob, {
                contentType: "image/png",
                upsert: true,
              });

            const { data: cleanUrlData } = supabase.storage
              .from("images")
              .getPublicUrl(cleanFileName);

            cleanImageUrl = cleanUrlData.publicUrl;
          }
        }
      } catch (e) {
        console.error("Watermark removal polling failed:", e);
        // Use original AI image
      }
    }

    // Update segment with clean image URL
    await supabase
      .from("segments")
      .update({
        clean_image_url: cleanImageUrl,
        status: "image_cleaned",
      })
      .eq("id", segmentId);

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "  ✓ Watermark removed successfully",
      log_type: "success",
    });

    return new Response(
      JSON.stringify({
        success: true,
        aiImageUrl,
        cleanImageUrl,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in generate-ai-character:", error);

    try {
      const { jobId, segmentId } = await req.clone().json();
      const supabase = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
      );

      if (jobId) {
        await supabase.from("logs").insert({
          job_id: jobId,
          message: `❌ Character generation failed: ${error.message}`,
          log_type: "error",
        });
      }

      if (segmentId) {
        await supabase
          .from("segments")
          .update({ status: "error", error_message: error.message })
          .eq("id", segmentId);
      }
    } catch {}

    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

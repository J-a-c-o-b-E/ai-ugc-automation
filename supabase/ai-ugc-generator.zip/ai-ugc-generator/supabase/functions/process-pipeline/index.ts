// supabase/functions/process-pipeline/index.ts
// Main orchestrator that runs the entire UGC generation pipeline

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { jobId } = await req.json();

    if (!jobId) {
      throw new Error("Missing jobId");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
    const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";

    // Get job details
    const { data: job, error: jobError } = await supabase
      .from("jobs")
      .select("*, characters(*)")
      .eq("id", jobId)
      .single();

    if (jobError || !job) {
      throw new Error("Job not found");
    }

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "═══════════════════════════════════════",
      log_type: "info",
    });
    await supabase.from("logs").insert({
      job_id: jobId,
      message: "🚀 Starting AI UGC Video Generation Pipeline",
      log_type: "info",
    });
    await supabase.from("logs").insert({
      job_id: jobId,
      message: "═══════════════════════════════════════",
      log_type: "info",
    });

    // Step 1: Download TikTok video
    const downloadResponse = await fetch(
      `${SUPABASE_URL}/functions/v1/download-tiktok`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          tiktokUrl: job.tiktok_url,
          jobId,
        }),
      }
    );

    const downloadResult = await downloadResponse.json();

    if (!downloadResult.success) {
      throw new Error(`Download failed: ${downloadResult.error}`);
    }

    // Step 2: Analyze video for UGC segments
    const analyzeResponse = await fetch(
      `${SUPABASE_URL}/functions/v1/analyze-video`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          videoUrl: downloadResult.videoUrl,
          jobId,
          videoDuration: downloadResult.duration,
        }),
      }
    );

    const analyzeResult = await analyzeResponse.json();

    if (!analyzeResult.success) {
      throw new Error(`Analysis failed: ${analyzeResult.error}`);
    }

    const segments = analyzeResult.segments;

    if (!segments || segments.length === 0) {
      throw new Error("No UGC segments detected in video");
    }

    // Update job status
    await supabase
      .from("jobs")
      .update({
        status: "generating_images",
        current_step: 4,
      })
      .eq("id", jobId);

    // Step 3-4: For each segment, extract frame and generate AI character
    // Note: Frame extraction is done client-side for efficiency
    // Here we assume frames are already uploaded or we use video thumbnails

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "📸 Processing segments...",
      log_type: "info",
    });

    // Get character description
    const characterDescription = job.characters?.description || "Professional looking person";
    const characterName = job.characters?.name || "AI Character";

    // Process each segment
    for (let i = 0; i < segments.length; i++) {
      const segment = segments[i];

      await supabase.from("logs").insert({
        job_id: jobId,
        message: `\n--- Processing Segment ${i + 1}/${segments.length} ---`,
        log_type: "info",
      });

      // For the frame URL, we'll use the video cover or a frame extracted from the segment
      // In a real implementation, you would extract the actual frame
      // For now, we'll use the original video URL with a timestamp parameter
      const frameUrl = segment.first_frame_url || downloadResult.cover || downloadResult.videoUrl;

      // Generate AI character image
      const characterResponse = await fetch(
        `${SUPABASE_URL}/functions/v1/generate-ai-character`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            segmentId: segment.id,
            frameUrl,
            characterDescription,
            characterName,
            jobId,
          }),
        }
      );

      const characterResult = await characterResponse.json();

      if (!characterResult.success) {
        await supabase.from("logs").insert({
          job_id: jobId,
          message: `⚠️ Character generation failed for segment ${i + 1}, skipping...`,
          log_type: "warning",
        });
        continue;
      }

      // Update segment with image URLs
      await supabase
        .from("segments")
        .update({
          ai_character_image_url: characterResult.aiImageUrl,
          clean_image_url: characterResult.cleanImageUrl,
        })
        .eq("id", segment.id);
    }

    // Update job status
    await supabase
      .from("jobs")
      .update({
        status: "generating_videos",
        current_step: 6,
      })
      .eq("id", jobId);

    // Step 5: Generate videos for each segment
    await supabase.from("logs").insert({
      job_id: jobId,
      message: "\n🎬 Starting video generation for all segments...",
      log_type: "info",
    });

    // Get updated segments with image URLs
    const { data: updatedSegments } = await supabase
      .from("segments")
      .select("*")
      .eq("job_id", jobId)
      .order("segment_index");

    for (let i = 0; i < (updatedSegments || []).length; i++) {
      const segment = updatedSegments![i];

      if (!segment.clean_image_url) {
        await supabase.from("logs").insert({
          job_id: jobId,
          message: `⚠️ Skipping segment ${i + 1} - no character image`,
          log_type: "warning",
        });
        continue;
      }

      // Generate video
      const videoResponse = await fetch(
        `${SUPABASE_URL}/functions/v1/generate-video`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({
            segmentId: segment.id,
            characterImageUrl: segment.clean_image_url,
            motionVideoUrl: segment.segment_video_url || downloadResult.videoUrl,
            jobId,
            segmentIndex: i,
          }),
        }
      );

      const videoResult = await videoResponse.json();

      if (!videoResult.success) {
        await supabase.from("logs").insert({
          job_id: jobId,
          message: `⚠️ Video generation failed for segment ${i + 1}: ${videoResult.error}`,
          log_type: "warning",
        });
      }
    }

    // Final status will be updated by generate-video when all segments complete
    return new Response(
      JSON.stringify({
        success: true,
        message: "Pipeline completed",
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in process-pipeline:", error);

    try {
      const { jobId } = await req.clone().json();
      if (jobId) {
        const supabase = createClient(
          Deno.env.get("SUPABASE_URL") ?? "",
          Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
        );

        await supabase.from("logs").insert({
          job_id: jobId,
          message: `❌ Pipeline failed: ${error.message}`,
          log_type: "error",
        });

        await supabase
          .from("jobs")
          .update({ status: "error", error_message: error.message })
          .eq("id", jobId);
      }
    } catch {}

    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

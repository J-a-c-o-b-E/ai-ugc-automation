// supabase/functions/analyze-video/index.ts
// Analyzes video to detect UGC segments where a person is visible
// Uses WaveSpeed Molmo2 Video Understanding API

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const WAVESPEED_API_BASE = "https://api.wavespeed.ai/api/v3";

interface Segment {
  start: number;
  end: number;
}

async function pollForResult(
  requestId: string,
  apiKey: string,
  maxAttempts = 60,
  intervalMs = 3000
): Promise<any> {
  for (let i = 0; i < maxAttempts; i++) {
    await new Promise((r) => setTimeout(r, intervalMs));

    const response = await fetch(
      `${WAVESPEED_API_BASE}/predictions/${requestId}/result`,
      {
        headers: { Authorization: `Bearer ${apiKey}` },
      }
    );

    const data = await response.json();

    if (data.status === "completed") {
      return data;
    } else if (data.status === "failed") {
      throw new Error(data.error || "Processing failed");
    }
    // Still processing, continue polling
  }

  throw new Error("Processing timed out");
}

function parseSegmentsFromResponse(output: string, videoDuration: number): Segment[] {
  try {
    // Try to find JSON array in response
    const jsonMatch = output.match(/\[[\s\S]*?\]/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed.map((seg: any) => ({
          start: Number(seg.start) || 0,
          end: Number(seg.end) || 5,
        }));
      }
    }

    // Try to find time ranges in format "X.X - Y.Y" or "X.Xs to Y.Ys"
    const timeRanges: Segment[] = [];
    const rangeRegex = /(\d+\.?\d*)\s*(?:s|seconds?)?\s*(?:-|to)\s*(\d+\.?\d*)\s*(?:s|seconds?)?/gi;
    let match;

    while ((match = rangeRegex.exec(output)) !== null) {
      const start = parseFloat(match[1]);
      const end = parseFloat(match[2]);
      if (!isNaN(start) && !isNaN(end) && end > start) {
        timeRanges.push({ start, end });
      }
    }

    if (timeRanges.length > 0) {
      return timeRanges;
    }

    // Fallback: if video is short, treat whole video as one segment
    // Otherwise, create segments every 10 seconds where person might appear
    if (videoDuration <= 15) {
      return [{ start: 0, end: videoDuration }];
    }

    // Default segmentation for longer videos
    const segments: Segment[] = [];
    const segmentDuration = 5;
    for (let i = 0; i < videoDuration; i += segmentDuration * 2) {
      segments.push({
        start: i,
        end: Math.min(i + segmentDuration, videoDuration),
      });
    }
    return segments.slice(0, 4); // Max 4 segments
  } catch (e) {
    console.error("Failed to parse segments:", e);
    // Ultimate fallback
    return [{ start: 0, end: Math.min(5, videoDuration) }];
  }
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { videoUrl, jobId, videoDuration } = await req.json();

    if (!videoUrl || !jobId) {
      throw new Error("Missing required parameters");
    }

    const WAVESPEED_API_KEY = Deno.env.get("WAVESPEED_API_KEY");
    if (!WAVESPEED_API_KEY) {
      throw new Error("WAVESPEED_API_KEY not configured");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "🔍 Analyzing video for UGC segments (person detection)...",
      log_type: "info",
    });

    // Call WaveSpeed Molmo2 Video Understanding API
    const analyzeResponse = await fetch(
      `${WAVESPEED_API_BASE}/wavespeed-ai/molmo2/video-understanding`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${WAVESPEED_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          video: videoUrl,
          task: "analysis",
          instruction: `Analyze this video and identify all time segments where a person is clearly visible speaking to camera (UGC/talking head style). 
          
Return ONLY a JSON array of segments with start and end times in seconds, like this:
[{"start": 0.0, "end": 5.2}, {"start": 12.5, "end": 18.8}]

Rules:
- Only include segments where a person's face/upper body is clearly visible
- Minimum segment duration: 2 seconds
- Maximum segments: 6
- If no person is detected, return the most visually interesting segments

Return ONLY the JSON array, no other text.`,
        }),
      }
    );

    if (!analyzeResponse.ok) {
      const errorText = await analyzeResponse.text();
      throw new Error(`WaveSpeed API error: ${analyzeResponse.status} - ${errorText}`);
    }

    const analyzeResult = await analyzeResponse.json();

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "  → Video analysis started, waiting for results...",
      log_type: "info",
    });

    // Poll for completion
    const result = await pollForResult(analyzeResult.id, WAVESPEED_API_KEY);

    // Parse segments from AI response
    const outputText = result.outputs?.[0] || result.output || "";
    const duration = videoDuration || 30;
    const segments = parseSegmentsFromResponse(outputText, duration);

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `✓ Detected ${segments.length} UGC segment(s)`,
      log_type: "success",
    });

    // Insert segments into database
    const segmentRecords = [];
    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i];
      let segDuration = seg.end - seg.start;
      let isLooped = false;
      let loopCount = 1;
      let finalDuration = segDuration;

      // Handle segments shorter than 3 seconds (Kling minimum)
      if (segDuration < 3) {
        isLooped = true;
        loopCount = Math.ceil(3 / segDuration);
        finalDuration = segDuration * loopCount;

        await supabase.from("logs").insert({
          job_id: jobId,
          message: `  ⟳ Segment ${i + 1}: ${seg.start.toFixed(1)}s - ${seg.end.toFixed(1)}s (${segDuration.toFixed(1)}s) - Will loop ${loopCount}x to reach ${finalDuration.toFixed(1)}s`,
          log_type: "warning",
        });
      } else {
        await supabase.from("logs").insert({
          job_id: jobId,
          message: `  → Segment ${i + 1}: ${seg.start.toFixed(1)}s - ${seg.end.toFixed(1)}s (${segDuration.toFixed(1)}s)`,
          log_type: "info",
        });
      }

      const { data: segmentData, error: insertError } = await supabase
        .from("segments")
        .insert({
          job_id: jobId,
          segment_index: i,
          start_time: seg.start,
          end_time: seg.end,
          duration: segDuration,
          final_duration: finalDuration,
          is_looped: isLooped,
          loop_count: loopCount,
          status: "pending",
        })
        .select()
        .single();

      if (insertError) {
        console.error("Failed to insert segment:", insertError);
      } else {
        segmentRecords.push(segmentData);
      }
    }

    // Update job status
    await supabase
      .from("jobs")
      .update({
        status: "extracting",
        current_step: 3,
        total_steps: 7,
      })
      .eq("id", jobId);

    return new Response(
      JSON.stringify({
        success: true,
        segments: segmentRecords,
        count: segments.length,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in analyze-video:", error);

    try {
      const { jobId } = await req.clone().json();
      if (jobId) {
        const supabase = createClient(
          Deno.env.get("SUPABASE_URL") ?? "",
          Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
        );

        await supabase.from("logs").insert({
          job_id: jobId,
          message: `❌ Video analysis failed: ${error.message}`,
          log_type: "error",
        });

        await supabase
          .from("jobs")
          .update({ status: "error", error_message: error.message })
          .eq("id", jobId);
      }
    } catch {}

    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

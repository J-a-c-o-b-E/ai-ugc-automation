// supabase/functions/generate-video/index.ts
// Generates AI UGC video using WaveSpeed Kling V2.6 Pro Motion Control

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const WAVESPEED_API_BASE = "https://api.wavespeed.ai/api/v3";

async function pollForResult(
  requestId: string,
  apiKey: string,
  supabase: any,
  jobId: string,
  maxAttempts = 120, // 10 minutes max (5s intervals)
  intervalMs = 5000
): Promise<any> {
  let lastLogTime = 0;

  for (let i = 0; i < maxAttempts; i++) {
    await new Promise((r) => setTimeout(r, intervalMs));

    const response = await fetch(
      `${WAVESPEED_API_BASE}/predictions/${requestId}/result`,
      {
        headers: { Authorization: `Bearer ${apiKey}` },
      }
    );

    const data = await response.json();

    // Log progress every 30 seconds
    const currentTime = Date.now();
    if (currentTime - lastLogTime > 30000) {
      await supabase.from("logs").insert({
        job_id: jobId,
        message: `  → Video still generating... (${Math.round((i * intervalMs) / 1000)}s elapsed)`,
        log_type: "info",
      });
      lastLogTime = currentTime;
    }

    if (data.status === "completed") {
      return data;
    } else if (data.status === "failed") {
      throw new Error(data.error || "Video generation failed");
    }
  }

  throw new Error("Video generation timed out after 10 minutes");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { segmentId, characterImageUrl, motionVideoUrl, jobId, segmentIndex } = await req.json();

    if (!segmentId || !characterImageUrl || !motionVideoUrl || !jobId) {
      throw new Error("Missing required parameters");
    }

    const WAVESPEED_API_KEY = Deno.env.get("WAVESPEED_API_KEY");
    if (!WAVESPEED_API_KEY) {
      throw new Error("WAVESPEED_API_KEY not configured");
    }

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `🎬 Generating AI video for segment ${(segmentIndex || 0) + 1} with Kling Motion Control...`,
      log_type: "info",
    });

    // Update segment status
    await supabase
      .from("segments")
      .update({ status: "video_generating" })
      .eq("id", segmentId);

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `  → Character image: ${characterImageUrl.split("/").pop()}`,
      log_type: "info",
    });
    await supabase.from("logs").insert({
      job_id: jobId,
      message: `  → Motion reference: ${motionVideoUrl.split("/").pop()}`,
      log_type: "info",
    });

    // Call WaveSpeed Kling V2.6 Pro Motion Control API
    const klingResponse = await fetch(
      `${WAVESPEED_API_BASE}/kwaivgi/kling-v2.6-pro/motion-control`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${WAVESPEED_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          image: characterImageUrl,
          video: motionVideoUrl,
          character_orientation: "image",
          keep_original_sound: false,
          prompt: "Professional UGC talking head video, natural lighting, social media content creator style, high quality, smooth motion",
          negative_prompt: "blurry, distorted, unnatural movement, artifacts, glitches",
        }),
      }
    );

    if (!klingResponse.ok) {
      const errorText = await klingResponse.text();
      throw new Error(`Kling API error: ${klingResponse.status} - ${errorText}`);
    }

    const klingResult = await klingResponse.json();

    if (!klingResult.id) {
      throw new Error("Failed to start video generation - no request ID returned");
    }

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `  → Video generation started (ID: ${klingResult.id})`,
      log_type: "info",
    });

    // Poll for completion
    const result = await pollForResult(
      klingResult.id,
      WAVESPEED_API_KEY,
      supabase,
      jobId
    );

    const outputVideoUrl = result.outputs?.[0];

    if (!outputVideoUrl) {
      throw new Error("No output video URL in result");
    }

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "  ✓ Video generated, downloading to storage...",
      log_type: "success",
    });

    // Download the generated video
    const videoResponse = await fetch(outputVideoUrl);
    if (!videoResponse.ok) {
      throw new Error(`Failed to download generated video: ${videoResponse.status}`);
    }

    const videoBlob = await videoResponse.arrayBuffer();

    // Upload to Supabase Storage
    const outputFileName = `${jobId}/output_segment_${segmentIndex || 0}.mp4`;

    const { error: uploadError } = await supabase.storage
      .from("videos")
      .upload(outputFileName, videoBlob, {
        contentType: "video/mp4",
        upsert: true,
      });

    if (uploadError) {
      throw new Error(`Failed to upload output video: ${uploadError.message}`);
    }

    const { data: urlData } = supabase.storage
      .from("videos")
      .getPublicUrl(outputFileName);

    const finalVideoUrl = urlData.publicUrl;

    // Update segment with output video URL
    await supabase
      .from("segments")
      .update({
        output_video_url: finalVideoUrl,
        status: "complete",
      })
      .eq("id", segmentId);

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `  ✓ AI UGC video ${(segmentIndex || 0) + 1} complete and saved`,
      log_type: "success",
    });

    // Check if all segments are complete
    const { data: segments } = await supabase
      .from("segments")
      .select("status")
      .eq("job_id", jobId);

    const allComplete = segments?.every((s: any) => s.status === "complete");

    if (allComplete) {
      await supabase
        .from("jobs")
        .update({
          status: "complete",
          current_step: 7,
        })
        .eq("id", jobId);

      await supabase.from("logs").insert({
        job_id: jobId,
        message: "═══════════════════════════════════════",
        log_type: "info",
      });
      await supabase.from("logs").insert({
        job_id: jobId,
        message: `✅ All ${segments.length} AI UGC videos generated successfully!`,
        log_type: "success",
      });
      await supabase.from("logs").insert({
        job_id: jobId,
        message: "═══════════════════════════════════════",
        log_type: "info",
      });
    }

    return new Response(
      JSON.stringify({
        success: true,
        outputVideoUrl: finalVideoUrl,
        allComplete,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in generate-video:", error);

    try {
      const { jobId, segmentId } = await req.clone().json();
      const supabase = createClient(
        Deno.env.get("SUPABASE_URL") ?? "",
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
      );

      if (jobId) {
        await supabase.from("logs").insert({
          job_id: jobId,
          message: `❌ Video generation failed: ${error.message}`,
          log_type: "error",
        });
      }

      if (segmentId) {
        await supabase
          .from("segments")
          .update({ status: "error", error_message: error.message })
          .eq("id", segmentId);
      }
    } catch {}

    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});

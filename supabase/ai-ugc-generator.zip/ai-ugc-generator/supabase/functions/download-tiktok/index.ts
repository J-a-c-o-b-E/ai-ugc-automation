// supabase/functions/download-tiktok/index.ts
// Downloads TikTok video without watermark using tikwm.com API

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TikWmResponse {
  code: number;
  msg: string;
  data: {
    id: string;
    title: string;
    play: string; // No watermark video URL
    wmplay: string; // With watermark
    music: string;
    duration: number;
    cover: string;
    origin_cover: string;
  };
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { tiktokUrl, jobId } = await req.json();

    if (!tiktokUrl || !jobId) {
      throw new Error("Missing required parameters: tiktokUrl and jobId");
    }

    // Initialize Supabase client with service role for backend operations
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Log start
    await supabase.from("logs").insert({
      job_id: jobId,
      message: "🎬 Fetching TikTok video metadata...",
      log_type: "info",
    });

    // Update job status
    await supabase
      .from("jobs")
      .update({ status: "downloading", current_step: 1 })
      .eq("id", jobId);

    // Call tikwm.com API to get video without watermark
    const tikwmUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}`;
    
    const tikwmResponse = await fetch(tikwmUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
      },
    });

    if (!tikwmResponse.ok) {
      throw new Error(`TikWm API error: ${tikwmResponse.status}`);
    }

    const tikwmData: TikWmResponse = await tikwmResponse.json();

    if (tikwmData.code !== 0) {
      throw new Error(`TikWm API error: ${tikwmData.msg}`);
    }

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `✓ Video metadata retrieved: "${tikwmData.data.title?.substring(0, 50)}..."`,
      log_type: "success",
    });

    await supabase.from("logs").insert({
      job_id: jobId,
      message: "📥 Downloading video (no watermark)...",
      log_type: "info",
    });

    // Download the video
    const videoUrl = tikwmData.data.play;
    const videoResponse = await fetch(videoUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!videoResponse.ok) {
      throw new Error(`Failed to download video: ${videoResponse.status}`);
    }

    const videoBlob = await videoResponse.blob();
    const videoArrayBuffer = await videoBlob.arrayBuffer();

    // Upload to Supabase Storage
    const fileName = `${jobId}/original.mp4`;
    const { error: uploadError } = await supabase.storage
      .from("videos")
      .upload(fileName, videoArrayBuffer, {
        contentType: "video/mp4",
        upsert: true,
      });

    if (uploadError) {
      throw new Error(`Storage upload failed: ${uploadError.message}`);
    }

    // Get public URL
    const { data: urlData } = supabase.storage
      .from("videos")
      .getPublicUrl(fileName);

    const publicUrl = urlData.publicUrl;

    // Update job with video info
    await supabase
      .from("jobs")
      .update({
        original_video_url: publicUrl,
        video_duration: tikwmData.data.duration,
        status: "analyzing",
        current_step: 2,
      })
      .eq("id", jobId);

    await supabase.from("logs").insert({
      job_id: jobId,
      message: `✓ Video downloaded successfully (${tikwmData.data.duration}s)`,
      log_type: "success",
    });

    return new Response(
      JSON.stringify({
        success: true,
        videoUrl: publicUrl,
        duration: tikwmData.data.duration,
        title: tikwmData.data.title,
        cover: tikwmData.data.cover,
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in download-tiktok:", error);

    // Try to log error to database
    try {
      const { jobId } = await req.clone().json();
      if (jobId) {
        const supabase = createClient(
          Deno.env.get("SUPABASE_URL") ?? "",
          Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
        );

        await supabase.from("logs").insert({
          job_id: jobId,
          message: `❌ Download failed: ${error.message}`,
          log_type: "error",
        });

        await supabase
          .from("jobs")
          .update({ status: "error", error_message: error.message })
          .eq("id", jobId);
      }
    } catch {}

    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
